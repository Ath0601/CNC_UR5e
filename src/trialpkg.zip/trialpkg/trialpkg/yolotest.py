import cv2
import torch
import time

# Path to your trained YOLOv5 .pt model
MODEL_PATH = '/home/atharva/trial_ws/src/yolov5/yolov5s.pt'

def main():
    # Load YOLOv5 model
    model = torch.hub.load('ultralytics/yolov5', 'custom', path=MODEL_PATH)
    print("Model loaded.")

    # Open webcam (0 = default camera)
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam.")
        return

    print("Press 'q' to exit.")
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture image")
            break

        # Inference
        results = model(frame)
        df = results.pandas().xyxy[0]

        for idx, row in df.iterrows():
            xmin, ymin, xmax, ymax, conf, cls, name = (
                int(row.xmin), int(row.ymin), int(row.xmax), int(row.ymax), row.confidence, row['class'], row.name)
            label = f"{name}: {conf:.2f}"
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0,255,0), 2)
            cv2.putText(frame, label, (xmin, ymin-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,0,0), 2)

        cv2.imshow("YOLOv5 Webcam Test", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
