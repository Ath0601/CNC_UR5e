import sys
sys.path.append('/home/atharva/yolov5')
print(sys.path)
from models.experimental import attempt_load

print("Imported successfully!")
