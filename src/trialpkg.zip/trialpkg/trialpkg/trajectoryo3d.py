import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Pose
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.action import ExecuteTrajectory
from rclpy.action import ActionClient
import numpy as np
import threading
from trialpkg.gcodeparser import GCodeParser

class CartesianPathClient(Node):
    def __init__(self):
        super().__init__('cartesian_path_client')
        self.workpiece_pose = None
        self.pose_received = threading.Event()

        # Subscribers and publishers
        self.pose_sub = self.create_subscription(PoseStamped, '/workpiece_pose', self.pose_callback, 1)

        # Service clients
        self.cartesian_client = self.create_client(GetCartesianPath, '/compute_cartesian_path')
        self.cartesian_client.wait_for_service()
        self.execute_client = ActionClient(self, ExecuteTrajectory, '/execute_trajectory')
        self.execute_client.wait_for_server()

        self.get_logger().info("Ready, waiting for vision pose.")

    def pose_callback(self, msg):
        self.workpiece_pose = msg
        self.pose_received.set()
        self.get_logger().info(f"Received workpiece pose: {msg}")

    def move_to_pose(self, pose: Pose):
        request = GetCartesianPath.Request()
        request.group_name = 'manipulator'
        request.header.frame_id = self.workpiece_pose.header.frame_id
        request.start_state.is_diff = True
        request.waypoints = [pose]
        request.max_step = 0.01
        request.jump_threshold = 0.0
        request.avoid_collisions = True
        future = self.cartesian_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        response = future.result()
        if response and response.fraction > 0.99:
            self.get_logger().info('Approach trajectory planned, executing...')
            goal_msg = ExecuteTrajectory.Goal()
            goal_msg.trajectory = response.solution
            send_goal_future = self.execute_client.send_goal_async(goal_msg)
            rclpy.spin_until_future_complete(self, send_goal_future)
            self.get_logger().info('Approach executed.')
        else:
            self.get_logger().error("Failed to plan approach trajectory!")

    def execute_gcode_trajectory(self, start_pose):
        # Parse your G-code file to get waypoints relative to the workpiece
        parser = GCodeParser("/home/atharva/trial_ws/src/trialpkg/gcodefiles/minimalspiral.gcode")
        gcode_poses = parser.parse()  # Relative to workpiece origin

        # Offset poses to be in robot frame (using start_pose as workpiece origin)
        offset = np.array([start_pose.position.x, start_pose.position.y, start_pose.position.z])
        poses = []
        for rel_pose in gcode_poses:
            p = Pose()
            p.position.x = rel_pose.position.x + offset[0]
            p.position.y = rel_pose.position.y + offset[1]
            p.position.z = rel_pose.position.z + offset[2]
            p.orientation = start_pose.orientation  # Or your desired orientation logic
            poses.append(p)

        # Plan and execute trajectory through these waypoints
        request = GetCartesianPath.Request()
        request.group_name = 'manipulator'
        request.header.frame_id = self.workpiece_pose.header.frame_id
        request.start_state.is_diff = True
        request.waypoints = poses
        request.max_step = 0.01
        request.jump_threshold = 0.0
        request.avoid_collisions = True
        future = self.cartesian_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        response = future.result()
        if response and response.fraction > 0.99:
            self.get_logger().info('GCode trajectory planned, executing...')
            goal_msg = ExecuteTrajectory.Goal()
            goal_msg.trajectory = response.solution
            send_goal_future = self.execute_client.send_goal_async(goal_msg)
            rclpy.spin_until_future_complete(self, send_goal_future)
            self.get_logger().info('GCode trajectory executed.')
        else:
            self.get_logger().error("Failed to plan GCode trajectory!")

def main(args=None):
    rclpy.init(args=args)
    node = CartesianPathClient()
    node.get_logger().info("Waiting for workpiece pose from vision node...")

    if not node.pose_received.wait(timeout=15):  # Increase timeout if needed
        node.get_logger().error("Did not receive workpiece pose in time. Exiting.")
        node.destroy_node()
        rclpy.shutdown()
        return

    approach_pose = node.workpiece_pose.pose
    node.move_to_pose(approach_pose)  # Step 1: move to detected workpiece pose

    node.execute_gcode_trajectory(approach_pose)  # Step 2: execute GCode trajectory starting here

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
