from pygcode import Line
import numpy as np
from geometry_msgs.msg import Pose
import math

class GCodeParser:
    def __init__(self, filepath, scale=1.0, z_height=0.2, debug=False):
        self.filepath = filepath
        self.scale = scale
        self.z_height = z_height
        self.debug = debug

    def euler_to_quat(self, roll, pitch, yaw):
        qx = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
        qy = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
        qz = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
        qw = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
        return qx, qy, qz, qw

    def sample_arc(self, start, end, center, direction, num=20):
        radius = np.linalg.norm(start - center)
        v0 = start - center
        v1 = end - center
        a0 = math.atan2(v0[1], v0[0])
        a1 = math.atan2(v1[1], v1[0])
        if direction == 'CW':
            if a1 > a0:
                a1 -= 2 * math.pi
            angles = np.linspace(a0, a1, num)
        else:
            if a1 < a0:
                a1 += 2 * math.pi
            angles = np.linspace(a0, a1, num)
        points = np.stack((center[0] + radius * np.cos(angles), center[1] + radius * np.sin(angles)), axis=-1)
        return points

    def arc_center_from_r(self, start, end, r, direction):
        mid = (start[:2] + end[:2]) / 2.0
        chord = end[:2] - start[:2]
        chord_len = np.linalg.norm(chord)
        if chord_len == 0:
            raise ValueError("Start and end for arc are identical!")
        r = abs(r)
        if r < chord_len / 2:
            raise ValueError("Radius too small for arc!")
        h = math.sqrt(r**2 - (chord_len/2)**2)
        perp = np.array([-chord[1], chord[0]])
        perp /= np.linalg.norm(perp)
        if direction == 'CW':
            perp = -perp
        center = mid + perp * h
        return center

    def parse(self):
        waypoints = []
        pos = np.array([0.0, 0.0, self.z_height])
        orientation = [0, 0, 0, 1]
        feedrate = 100.0
        absolute = True
        motion_mode = None

        with open(self.filepath, 'r') as f:
            for line in f:
                try:
                    g_line = Line(line)
                    block = g_line.block
                    print(f"[DEBUG] Reading line: {line.strip()}")

                    words = getattr(block, 'words', [])
                    g_code_in_words = None

                    # Find motion mode in words (G0, G1, G2, G3, etc)
                    for w in words:
                        if w.letter == 'G':
                            code = int(w.value)
                            if code in (0, 1, 2, 3):
                                g_code_in_words = code
                                motion_mode = code  # Set active motion mode
                            elif code == 20:
                                self.scale = 0.0254
                            elif code == 21:
                                self.scale = 0.001
                            elif code == 90:
                                absolute = True
                            elif code == 91:
                                absolute = False

                    # Update feedrate if present
                    for w in words:
                        if w.letter == 'F':
                            feedrate = float(w.value)

                    # Only parse if current line is G0, G1, G2, G3 or if motion_mode persists
                    if motion_mode in (0, 1, 2, 3):
                        end_pos = pos.copy()
                        i = j = r = None
                        for w in words:
                            if w.letter == 'X':
                                end_pos[0] = float(w.value) * self.scale if absolute else pos[0] + float(w.value) * self.scale
                            if w.letter == 'Y':
                                end_pos[1] = float(w.value) * self.scale if absolute else pos[1] + float(w.value) * self.scale
                            if w.letter == 'Z':
                                end_pos[2] = float(w.value) * self.scale if absolute else pos[2] + float(w.value) * self.scale
                            if w.letter == 'I':
                                i = float(w.value) * self.scale
                            if w.letter == 'J':
                                j = float(w.value) * self.scale
                            if w.letter == 'R':
                                r = float(w.value) * self.scale

                        if motion_mode in (0, 1):  # Linear moves
                            if not np.allclose(end_pos, pos):
                                pose = Pose()
                                pose.position.x = float(end_pos[0])
                                pose.position.y = float(end_pos[1])
                                pose.position.z = float(end_pos[2])
                                pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w = orientation
                                waypoints.append(pose)
                                pos = end_pos.copy()
                                print(f"[DEBUG] Linear waypoint added: {pose.position.x}, {pose.position.y}, {pose.position.z}")

                        elif motion_mode in (2, 3):  # Arc moves
                            direction = 'CW' if motion_mode == 2 else 'CCW'
                            if i is not None and j is not None:
                                center = np.array([pos[0] + i, pos[1] + j])
                                arc_points = self.sample_arc(pos[:2], end_pos[:2], center, direction, num=20)
                            elif r is not None:
                                center = self.arc_center_from_r(pos, end_pos, r, direction)
                                arc_points = self.sample_arc(pos[:2], end_pos[:2], center, direction, num=20)
                            else:
                                continue
                            for pt in arc_points:
                                pose = Pose()
                                pose.position.x = float(pt[0])
                                pose.position.y = float(pt[1])
                                pose.position.z = float(end_pos[2])
                                pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w = orientation
                                waypoints.append(pose)
                            pos = end_pos.copy()
                            print(f"[DEBUG] Arc waypoint(s) added (G2/G3) to: {end_pos}")

                except Exception as e:
                    if self.debug:
                        print(f"[WARN] G-code parse error: {e} | line: {line.strip()}")
        return waypoints
