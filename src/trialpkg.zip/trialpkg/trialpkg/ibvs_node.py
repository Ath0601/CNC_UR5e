#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from sensor_msgs.msg import Image
from geometry_msgs.msg import TwistStamped
from cv_bridge import CvBridge

class IBVSServoNode(Node):
    def __init__(self):
        super().__init__('ibvs_servo_node')
        self.camera_matrix = np.array([[615.0, 0, 320], [0, 615.0, 240], [0, 0, 1]])
        self.lam = 0.5
        self.bridge = CvBridge()
        self.desired_uv = np.array([320, 240])
        self.image_pub = self.create_publisher(Image, '/ibvs/debug_image', 10)
        self.create_subscription(Image, '/camera/color/image_raw', self.image_callback, 10)
        self.servo_pub = self.create_publisher(TwistStamped, '/servo_node/delta_twist_cmds', 10)
        self.get_logger().info('IBVS Servo Node Initialized')

    def image_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        # Example: Blue marker detection
        hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
        lower_blue = np.array([100, 150, 50])
        upper_blue = np.array([130, 255, 255])
        mask = cv2.inRange(hsv, lower_blue, upper_blue)
        M = cv2.moments(mask)
        if M['m00'] == 0:
            self.get_logger().warn('Tool tip (blue marker) not detected!')
            return
        cx = int(M['m10'] / M['m00'])
        cy = int(M['m01'] / M['m00'])
        tool_uv = np.array([cx, cy])

        debug_image = cv_image.copy()
        cv2.circle(debug_image, (cx, cy), 5, (0,255,0), -1)
        debug_msg = self.bridge.cv2_to_imgmsg(debug_image, encoding='bgr8')
        self.image_pub.publish(debug_msg)

        # IBVS error (pixels)
        error = self.desired_uv - tool_uv
        self.get_logger().info(f'Image error (pixels): {error}')

        # Interaction matrix L for point
        Z = 1.0
        fx, fy = self.camera_matrix[0,0], self.camera_matrix[1,1]
        L = np.array([[-fx/Z, 0],
                      [0, -fy/Z]])
        v = self.lam * np.linalg.pinv(L).dot(error.reshape(2,1))

        twist = TwistStamped()
        twist.header.stamp = msg.header.stamp
        twist.header.frame_id = 'ee_link'
        twist.twist.linear.x = float(v[0])
        twist.twist.linear.y = float(v[1])
        twist.twist.linear.z = 0.0
        twist.twist.angular.x = 0.0
        twist.twist.angular.y = 0.0
        twist.twist.angular.z = 0.0

        self.servo_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = IBVSServoNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
