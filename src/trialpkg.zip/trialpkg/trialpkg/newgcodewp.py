import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, PoseArray, PoseStamped
from visualization_msgs.msg import Marker, MarkerArray
from moveit_msgs.srv import GetCartesianPath, GetPositionIK, GetStateValidity
from moveit_msgs.msg import RobotState
from moveit_msgs.action import ExecuteTrajectory
from rclpy.action import ActionClient
import numpy as np
from scipy.spatial.transform import Rotation as R
from trialpkg.gcodeparser import GCodeParser  # Make sure this imports your working parser

class CartesianTrajectoryNode(Node):
    def __init__(self):
        super().__init__('cartesian_trajectory_node')

        # Visualization
        self.marker_pub = self.create_publisher(MarkerArray, '/gcode_waypoint_markers', 1)
        self.posearray_pub = self.create_publisher(PoseArray, '/gcode_waypoint_poses', 1)
        #self.filepath = '/home/atharva/trial_ws/src/trialpkg/gcodefiles/big_movements_50cm_xy.gcode'

        # MoveIt clients
        self.cartesian_client = self.create_client(GetCartesianPath, '/compute_cartesian_path')
        self.execute_client = ActionClient(self, ExecuteTrajectory, '/execute_trajectory')
        self.get_logger().info('Waiting for MoveIt services...')
        self.cartesian_client.wait_for_service()
        self.execute_client.wait_for_server()
        self.get_logger().info('Connected to MoveIt.')
        self.state_validity_client = self.create_client(GetStateValidity, '/check_state_validity')
        self.state_validity_client.wait_for_service()

        # Parse GCode and send waypoints
        '''
        parser = GCodeParser(self.filepath, debug=True)
        raw_waypoints = parser.parse()
        self.get_logger().info(f"DEBUG: {len(raw_waypoints)} waypoints parsed from {self.filepath}")
        '''

        # Apply consistent orientation (tool pointing down)
        poses = []
        quat = R.from_euler('xyz', [-np.pi/2, 0, 0]).as_quat()
        #for i, p in enumerate(raw_waypoints):
        for x, y, z in [(0.4,0.0,0.35),(0.5,0.0,0.35),(0.5,0.1,0.35),(0.4,0.1,0.35),(0.4,0.0,0.35)]:
            pose = Pose()
            pose.position.x = x
            pose.position.y = y
            pose.position.z = z
            pose.orientation.x = float(quat[0])
            pose.orientation.y = float(quat[1])
            pose.orientation.z = float(quat[2])
            pose.orientation.w = float(quat[3])
            poses.append(pose)
            self.get_logger().info(f"DEBUG Waypoint {x,y,z}: x={pose.position.x}, y={pose.position.y}, z={pose.position.z}")

        self.visualize_waypoints(poses)
        self.plan_and_execute(poses)

    def check_collision(self, joint_state, group='manipulator'):
        req = GetStateValidity.Request()
        req.robot_state.joint_state = joint_state
        req.group_name = group
        future = self.state_validity_client.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        result = future.result()
        return result.valid, result.contacts

    def visualize_waypoints(self, poses):
        marker_array = MarkerArray()
        for i, pose in enumerate(poses):
            m = Marker()
            m.header.frame_id = 'base_link'
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = 'gcode_waypoints'
            m.id = i
            m.type = Marker.SPHERE
            m.action = Marker.ADD
            m.pose = pose
            m.scale.x = m.scale.y = m.scale.z = 0.02
            m.color.r = 1.0
            m.color.g = 0.2
            m.color.b = 0.2
            m.color.a = 1.0
            marker_array.markers.append(m)
        self.marker_pub.publish(marker_array)

        pa = PoseArray()
        pa.header.frame_id = 'base_link'
        pa.poses = poses
        self.posearray_pub.publish(pa)
        self.get_logger().info(f"Published {len(poses)} waypoints for visualization.")

    def plan_and_execute(self, poses):
        req = GetCartesianPath.Request()
        req.header.frame_id = 'base_link'
        req.group_name = 'manipulator'
        req.link_name = 'end_mill_link'
        req.max_step = 0.1
        req.jump_threshold = 0.0
        req.avoid_collisions = False
        req.waypoints = poses

        ik_client = self.create_client(GetPositionIK, '/compute_ik')
        ik_client.wait_for_service()

        for i, pose in enumerate(poses):
            ik_req = GetPositionIK.Request()
            ik_req.ik_request.group_name = 'manipulator'
            ik_req.ik_request.robot_state.joint_state.name = []  
            ik_req.ik_request.pose_stamped = PoseStamped()
            ik_req.ik_request.pose_stamped.header.frame_id = 'base_link'
            ik_req.ik_request.pose_stamped.pose = pose
            ik_req.ik_request.ik_link_name = 'end_mill_link'
            ik_req.ik_request.timeout.sec = 1
            future = ik_client.call_async(ik_req)
            rclpy.spin_until_future_complete(self, future)
            result = future.result()
            ik_result = future.result()
            if result.error_code.val == result.error_code.SUCCESS:
                self.get_logger().info(f"IK solution exists for waypoint {i}")
                js = ik_result.solution.joint_state
                valid, contacts = self.check_collision(js)
                if not valid:
                    self.get_logger().warn(f"Waypoint {i} is in collision!")
                    for contact in contacts:
                            self.get_logger().warn(f"Collision between {contact.contact_body_1} and {contact.contact_body_2} (depth: {contact.depth})")
            else:
                self.get_logger().warn(f"No IK solution for waypoint {i}")

        self.get_logger().info(f"Requesting Cartesian path through {len(poses)} waypoints...")
        self.get_logger().info(f"group_name: {req.group_name}, link_name: {req.link_name}, frame_id: {req.header.frame_id}")
        self.get_logger().info(f"First waypoint: x={poses[0].position.x}, y={poses[0].position.y}, z={poses[0].position.z}")
        future = self.cartesian_client.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        result = future.result()

        if result is not None:
            self.get_logger().info(f"MoveIt response: {result}")


        if result is not None and result.fraction > 0.95:
            self.get_logger().info(f"Planned Cartesian path ({result.fraction*100:.1f}%). Sending to execution...")
            goal_msg = ExecuteTrajectory.Goal()
            goal_msg.trajectory = result.solution
            exec_future = self.execute_client.send_goal_async(goal_msg)
            rclpy.spin_until_future_complete(self, exec_future)
            exec_result = exec_future.result()
            self.get_logger().info(f"Execution result: {exec_result}")
        else:
            self.get_logger().error(f"Planning failed or low fraction ({result.fraction if result else 0:.2f}). Check your waypoints or robot workspace.")
            for i in range(len(req.waypoints) - 1):
                req_test = GetCartesianPath.Request()
                req_test.header.frame_id = 'base_link'
                req_test.group_name = 'manipulator'
                req_test.link_name = 'end_mill_link'
                req_test.max_step = 0.05
                req_test.jump_threshold = 0.0
                req_test.avoid_collisions = False
                req_test.waypoints = [req.waypoints[i], req.waypoints[i + 1]]
                self.get_logger().info(f"Trying waypoint pair {i} -> {i+1}")
                test_future = self.cartesian_client.call_async(req_test)
                rclpy.spin_until_future_complete(self, test_future)
                test_result = test_future.result()
                self.get_logger().info(f"  Fraction: {test_result.fraction:.3f}")
                if test_result.fraction < 0.99:
                    self.get_logger().error(f"Path failed between waypoints {i} and {i+1}")

def main(args=None):
    rclpy.init(args=args)
    node = CartesianTrajectoryNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
