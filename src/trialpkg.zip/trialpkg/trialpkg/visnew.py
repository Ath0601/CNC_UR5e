import rclpy, torch, cv2
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Float32MultiArray
from cv_bridge import CvBridge
import numpy as np
import sys
sys.path.append('/home/atharva/trial_ws/src/yolov5')
from models.experimental import attempt_load

class YOLOv5VisionNode(Node):
    def __init__(self):
        super().__init__('yolov5_vision_node')
        self.bridge = CvBridge()
        self.color_sub = self.create_subscription(Image, '/camera/color/image_raw', self.color_callback, 10)
        self.depth_sub = self.create_subscription(Image, '/camera/aligned_depth_to_color/image_raw', self.depth_callback, 10)
        self.info_sub = self.create_subscription(CameraInfo, '/camera/color/camera_info', self.info_callback, 10)
        self.pose_pub = self.create_publisher(PoseStamped, '/workpiece_pose', 10)
        self.length_pub = self.create_publisher(Float32MultiArray, '/workpiece_edge_lengths', 10)
        self.color_image = None
        self.depth_image = None
        self.camera_info = None
        weights = '/home/atharva/trial_ws/src/yolov5/yolov5s.pt'
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = attempt_load(weights, device=device)

    def info_callback(self, msg):
        self.camera_info = msg

    def color_callback(self, msg):
        self.color_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='rgb8')
        self.process()

    def depth_callback(self, msg):
        self.depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')

    def process(self):
        if self.color_image is None or self.depth_image is None or self.camera_info is None:
            return

        results = self.model(self.color_image)
        df = results.pandas().xyxy[0]
        if df.empty:
            return
        row = df.iloc[0]
        xmin, ymin, xmax, ymax = map(int, [row.xmin, row.ymin, row.xmax, row.ymax])
        cx = int((xmin + xmax) / 2)
        cy = int((ymin + ymax) / 2)
        img = self.color_image.copy()
        cv2.rectangle(img, (xmin, ymin), (xmax, ymax), (0,255,0), 2)
        cv2.circle(img, (cx, cy), 5, (0,0,255), -1)

        if self.depth_image.shape[:2] != img.shape[:2]:
            depth_img_resized = cv2.resize(self.depth_image, (img.shape[1], img.shape[0]))
        else:
            depth_img_resized = self.depth_image

        K = self.camera_info.k
        fx, fy = K[0], K[4]
        cx_i, cy_i = K[2], K[5]

        # Corners in 3D
        corners_2d = [(xmin, ymin), (xmax, ymin), (xmin, ymax), (xmax, ymax)]
        corners_3d = []
        for u, v in corners_2d:
            depth = self.get_depth_avg(depth_img_resized, u, v)
            if depth == 0.0:
                continue
            depth = depth / 1000.0
            X = (u - cx_i) * depth / fx
            Y = (v - cy_i) * depth / fy
            Z = depth
            corners_3d.append(np.array([X, Y, Z]))

        if len(corners_3d) == 4:
            len_top = np.linalg.norm(corners_3d[0] - corners_3d[1])
            len_left = np.linalg.norm(corners_3d[0] - corners_3d[2])
            len_bottom = np.linalg.norm(corners_3d[2] - corners_3d[3])
            len_right = np.linalg.norm(corners_3d[1] - corners_3d[3])
            len_x = (len_top + len_bottom) / 2
            len_y = (len_left + len_right) / 2
        else:
            len_x, len_y = 0.0, 0.0

        center_depth = self.get_depth_avg(depth_img_resized, cx, cy) / 1000.0
        X = (cx - cx_i) * center_depth / fx
        Y = (cy - cy_i) * center_depth / fy
        Z = center_depth

        # Publish PoseStamped
        pose_msg = PoseStamped()
        pose_msg.header.stamp = self.get_clock().now().to_msg()
        pose_msg.header.frame_id = self.camera_info.header.frame_id
        pose_msg.pose.position.x = float(X)
        pose_msg.pose.position.y = float(Y)
        pose_msg.pose.position.z = float(Z)
        pose_msg.pose.orientation.w = 1.0
        self.pose_pub.publish(pose_msg)

        # Publish edge lengths as Float32MultiArray
        length_msg = Float32MultiArray()
        length_msg.data = [float(len_x), float(len_y)]
        self.length_pub.publish(length_msg)

        # (Optional: visual debug window)
        label = f"{len_x:.3f}m x {len_y:.3f}m"
        cv2.putText(img, label, (xmin, ymin-15), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,255), 2)
        cv2.imshow("YOLOv5 Detection", img)
        cv2.waitKey(1)

    def get_depth_avg(self, depth_img, u, v, window=3):
        h, w = depth_img.shape[:2]
        x0 = max(0, u - window // 2)
        x1 = min(w, u + window // 2 + 1)
        y0 = max(0, v - window // 2)
        y1 = min(h, v + window // 2 + 1)
        region = depth_img[y0:y1, x0:x1]
        valid = region[(region > 0)]
        if valid.size > 0:
            return float(np.mean(valid))
        return 0.0

def main(args=None):
    rclpy.init(args=args)
    node = YOLOv5VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
