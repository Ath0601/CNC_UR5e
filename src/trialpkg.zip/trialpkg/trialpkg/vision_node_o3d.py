import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
from geometry_msgs.msg import PoseStamped, TransformStamped
from std_msgs.msg import Float32MultiArray
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
import open3d as o3d
from tf2_ros import TransformBroadcaster

class PCSegVisionNode(Node):
    def __init__(self):
        super().__init__('pcseg_vision_node')
        self.pc_sub = self.create_subscription(PointCloud2, '/camera/depth/color/points', self.pc_callback, 1)
        self.pose_pub = self.create_publisher(PoseStamped, '/workpiece_pose', 10)
        self.dimension_pub = self.create_publisher(Float32MultiArray, '/workpiece_dimensions', 10)
        self.tf_broadcaster = TransformBroadcaster(self)
        self.last_pose = None

    def pc_callback(self, msg):
        # Convert PointCloud2 to numpy array
        xyz = []
        for p in pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z")):
            xyz.append([p[0], p[1], p[2]])
        if not xyz:
            return
        pts = np.array(xyz)
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(pts)

        # Crop the scene to your workspace (adjust bounds!)
        workspace = o3d.geometry.AxisAlignedBoundingBox(
            min_bound=[-0.5, -0.5, 0.0],
            max_bound=[0.5, 0.5, 1.0]
        )
        pcd = pcd.crop(workspace)

        # Downsample for speed
        pcd = pcd.voxel_down_sample(voxel_size=0.003)

        # Remove table plane using RANSAC
        plane_model, inliers = pcd.segment_plane(distance_threshold=0.005, ransac_n=3, num_iterations=200)
        objects = pcd.select_by_index(inliers, invert=True)

        # Euclidean clustering for objects
        labels = np.array(objects.cluster_dbscan(eps=0.01, min_points=50))
        if labels.max() < 0:
            return  # No clusters found

        # Select the largest cluster (assumed workpiece)
        largest_cluster_idx = np.argmax(np.bincount(labels[labels >= 0]))
        workpiece = objects.select_by_index(np.where(labels == largest_cluster_idx)[0])

        # Get oriented bounding box and centroid
        obb = workpiece.get_oriented_bounding_box()
        center = obb.center
        extent = obb.extent  # length, width, height
        rot = obb.R  # 3x3 rotation matrix

        # Publish pose (centroid, identity quaternion here)
        pose_msg = PoseStamped()
        pose_msg.header.stamp = self.get_clock().now().to_msg()
        pose_msg.header.frame_id = msg.header.frame_id
        pose_msg.pose.position.x = float(center[0])
        pose_msg.pose.position.y = float(center[1])
        pose_msg.pose.position.z = float(center[2])
        pose_msg.pose.orientation.w = 1.0  # You can convert rot to quaternion for true orientation

        self.pose_pub.publish(pose_msg)

        # Publish dimensions
        dim_msg = Float32MultiArray()
        dim_msg.data = [float(x) for x in extent]
        self.dimension_pub.publish(dim_msg)

        # Optionally broadcast TF
        tf_msg = TransformStamped()
        tf_msg.header = pose_msg.header
        tf_msg.child_frame_id = 'workpiece'
        tf_msg.transform.translation.x = float(center[0])
        tf_msg.transform.translation.y = float(center[1])
        tf_msg.transform.translation.z = float(center[2])
        tf_msg.transform.rotation = pose_msg.pose.orientation
        self.tf_broadcaster.sendTransform(tf_msg)

        self.get_logger().info(f"Detected workpiece centroid: {center}, dimensions: {extent}")

        # Uncomment for debugging/visualization (runs in headless mode in ROS2)
        # o3d.visualization.draw_geometries([workpiece, obb])

def main(args=None):
    rclpy.init(args=args)
    node = PCSegVisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
