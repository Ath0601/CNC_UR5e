from pygcode import Line
import numpy as np
from geometry_msgs.msg import Pose
import math
from scipy.spatial.transform import Rotation as R
from trialpkg.urik import ur5e_ik

class GCodeParser:
    def __init__(self, filepath, scale=1.0, z_height=0.35, debug=False):
        self.filepath = filepath
        self.scale = scale
        self.z_height = z_height
        self.debug = debug

    def euler_to_quat(self, roll, pitch, yaw):
        qx = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
        qy = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
        qz = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
        qw = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
        return qx, qy, qz, qw

    def sample_arc(self, start, end, center, direction, num=20):
        radius = np.linalg.norm(start - center)
        v0 = start - center
        v1 = end - center
        a0 = math.atan2(v0[1], v0[0])
        a1 = math.atan2(v1[1], v1[0])
        if direction == 'CW':
            if a1 > a0:
                a1 -= 2 * math.pi
            angles = np.linspace(a0, a1, num)
        else:
            if a1 < a0:
                a1 += 2 * math.pi
            angles = np.linspace(a0, a1, num)
        points = np.stack((center[0] + radius * np.cos(angles), center[1] + radius * np.sin(angles)), axis=-1)
        return points

    def arc_center_from_r(self, start, end, r, direction):
        mid = (start[:2] + end[:2]) / 2.0
        chord = end[:2] - start[:2]
        chord_len = np.linalg.norm(chord)
        if chord_len == 0:
            raise ValueError("Start and end for arc are identical!")
        r = abs(r)
        if r < chord_len / 2:
            raise ValueError("Radius too small for arc!")
        h = math.sqrt(r**2 - (chord_len/2)**2)
        perp = np.array([-chord[1], chord[0]])
        perp /= np.linalg.norm(perp)
        if direction == 'CW':
            perp = -perp
        center = mid + perp * h
        return center

    def parse(self):
        waypoints = []
        pos = np.array([0.0, 0.0, self.z_height])
        quat = R.from_euler('xyz', [-np.pi/2, 0, 0]).as_quat()
        orientation = [float(quat[0]), float(quat[1]), float(quat[2]), float(quat[3])]
        absolute = True

        with open(self.filepath, 'r') as f:
            for line in f:
                print("[DEBUG] Reading line:", line.strip())
                if line.startswith('G21'):
                    self.scale = 0.001
                if line.startswith('G1'):
                    words = line.split()
                    x = y = None
                    for word in words:
                        if word.startswith('X'):
                            x = float(word[1:]) * self.scale
                        if word.startswith('Y'):
                            y = float(word[1:]) * self.scale
                    if x is not None and y is not None:
                        pose = Pose()
                        pose.position.x = x
                        pose.position.y = y
                        pose.position.z = self.z_height
                        pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w = orientation
                        waypoints.append(pose)
                        print(f"[DEBUG] Linear waypoint added: {pose.position.x}, {pose.position.y}, {pose.position.z}")
        return waypoints

def main():
    parser = GCodeParser('/home/atharva/trial_ws/src/trialpkg/gcodefiles/spiral 6 cm line x_0001.gcode')
    poses = parser.parse()
    for p in poses:
        x = p.position.x
        y = p.position.y
        z = p.position.z
        ik = np.array(ur5e_ik(x,y,z))
        ikdeg = np.round(np.rad2deg(ik),3)
    print("Parsed waypoints are: ", poses)
    print("IK Solution for each pose is ", ikdeg)

if __name__ == '__main__':
    main()
