import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import MotionPlanRequest, Constraints, PositionConstraint, OrientationConstraint, WorkspaceParameters
from builtin_interfaces.msg import Duration
from trajectory_msgs.msg import JointTrajectory
from action_msgs.msg import GoalStatus
from rclpy.action import ActionClient
from shape_msgs.msg import SolidPrimitive

class JointSpacePlanner(Node):
    def __init__(self):
        super().__init__('joint_space_planner')
        super().__init__('joint_space_planner')
        self._action_client = ActionClient(self, MoveGroup, '/move_action')
        self.get_logger().info("Waiting for MoveGroup action server...")
        self._action_client.wait_for_server()
        self.get_logger().info("MoveGroup action server available!")
        self.group_name = 'manipulator'
        self.end_effector_link = 'wrist_3_link'

        # Define your target pose here:
        self.pose_target = PoseStamped()
        self.pose_target.header.frame_id = 'base_link'
        self.pose_target.pose.position.x = 0.3
        self.pose_target.pose.position.y = 0.0
        self.pose_target.pose.position.z = 0.4
        self.pose_target.pose.orientation.x = 0.0
        self.pose_target.pose.orientation.y = 0.0
        self.pose_target.pose.orientation.z = 0.0
        self.pose_target.pose.orientation.w = 1.0

        # Create MoveGroup action client
        self.timer = self.create_timer(5.0, self.send_goal)

    def send_goal(self):
        if not self._action_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error("MoveGroup action server not available!")
            return

        goal = MoveGroup.Goal()
        req = MotionPlanRequest()
        req.group_name = self.group_name
        req.num_planning_attempts = 10
        req.allowed_planning_time = 5.0
        req.max_velocity_scaling_factor = 0.2
        req.max_acceleration_scaling_factor = 0.2

        # Set workspace (optional, can be omitted)
        req.workspace_parameters.header.frame_id = 'base_link'
        req.workspace_parameters.min_corner.x = -1.0
        req.workspace_parameters.min_corner.y = -1.0
        req.workspace_parameters.min_corner.z =  0.0
        req.workspace_parameters.max_corner.x =  1.0
        req.workspace_parameters.max_corner.y =  1.0
        req.workspace_parameters.max_corner.z =  1.5

        # Set target pose
        pos_constraint = PositionConstraint()
        pos_constraint.header = self.pose_target.header
        pos_constraint.link_name = self.end_effector_link
        pos_constraint.constraint_region.primitives.append(
            self.create_box_primitive(0.005, 0.005, 0.005)
        )
        pos_constraint.constraint_region.primitive_poses.append(self.pose_target.pose)
        pos_constraint.weight = 1.0

        orient_constraint = OrientationConstraint()
        orient_constraint.header = self.pose_target.header
        orient_constraint.link_name = self.end_effector_link
        orient_constraint.orientation = self.pose_target.pose.orientation
        orient_constraint.absolute_x_axis_tolerance = 0.1
        orient_constraint.absolute_y_axis_tolerance = 0.1
        orient_constraint.absolute_z_axis_tolerance = 0.1
        orient_constraint.weight = 1.0

        req.goal_constraints.append(Constraints(
            position_constraints=[pos_constraint],
            orientation_constraints=[orient_constraint]
        ))

        goal.request = req
        goal.planning_options.plan_only = True

        send_future = self._action_client.send_goal_async(goal)
        send_future.add_done_callback(self.goal_response_callback)

        self.get_logger().info("Sent goal to MoveGroup action server.")

        # Only send once
        self.timer.cancel()

    def create_box_primitive(self, x, y, z):
        prim = SolidPrimitive()
        prim.type = SolidPrimitive.BOX
        prim.dimensions = [x, y, z]
        return prim

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("Goal rejected by server!")
            return
        self.get_logger().info("Goal accepted! Waiting for result...")
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.result_callback)

    def result_callback(self, future):
        result = future.result().result
        if result.error_code.val == 1:  # SUCCESS
            self.get_logger().info("Plan and execution successful!")
        else:
            self.get_logger().error(f"Planning/execution failed: error code {result.error_code.val}")

def main(args=None):
    rclpy.init(args=args)
    node = JointSpacePlanner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
