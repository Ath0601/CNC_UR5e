import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Float32MultiArray
from cv_bridge import CvBridge
import numpy as np
import open3d as o3d
import sensor_msgs_py.point_cloud2 as pc2
import tf_transformations

class O3DVisionNode(Node):
    def __init__(self):
        super().__init__('o3d_vision_node')
        self.pc_sub = self.create_subscription(PointCloud2, '/camera/depth/color/points', self.pc_callback, 1)
        self.pose_pub = self.create_publisher(PoseStamped, '/workpiece_pose', 1)
        self.dim_pub = self.create_publisher(Float32MultiArray, '/workpiece_dimensions', 1)
        self.bridge = CvBridge()

    def pc_callback(self, msg):
        points = np.array([p[:3] for p in pc2.read_points(msg, skip_nans=True)])
        if len(points) < 100:
            self.get_logger().warning("No points in cloud")
            return

        # Create o3d point cloud and segment
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd = pcd.voxel_down_sample(voxel_size=0.003)
        labels = np.array(pcd.cluster_dbscan(eps=0.01, min_points=20))
        if labels.max() < 0:
            self.get_logger().warning("No clusters found")
            return
        # Largest cluster = workpiece
        largest = np.argmax(np.bincount(labels[labels >= 0]))
        mask = labels == largest
        workpiece = pcd.select_by_index(np.where(mask)[0])
        if len(workpiece.points) < 30:
            self.get_logger().warning("Not enough points for workpiece")
            return

        # OBB: orientation, centroid, edge lengths
        obb = workpiece.get_oriented_bounding_box()
        center = obb.center
        rot = obb.R
        extent = obb.extent  # length, width, height (ordered by OBB)
        # Orientation as quaternion
        quat = tf_transformations.quaternion_from_matrix(np.vstack((np.hstack((rot, np.array([[0],[0],[0]]))), [0,0,0,1])))

        # Publish PoseStamped
        pose_msg = PoseStamped()
        pose_msg.header = msg.header
        pose_msg.pose.position.x, pose_msg.pose.position.y, pose_msg.pose.position.z = center
        pose_msg.pose.orientation.x, pose_msg.pose.orientation.y, pose_msg.pose.orientation.z, pose_msg.pose.orientation.w = quat
        self.pose_pub.publish(pose_msg)

        # Publish edge lengths (dimensions)
        dim_msg = Float32MultiArray()
        dim_msg.data = extent.tolist()
        self.dim_pub.publish(dim_msg)

        # Log for debug
        self.get_logger().info(
            f"Workpiece: Center={np.round(center,3)}, Dimensions={np.round(extent,3)}, Orientation Q={np.round(quat,3)}"
        )

def main(args=None):
    rclpy.init(args=args)
    node = O3DVisionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
