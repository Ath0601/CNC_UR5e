import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped
from cv_bridge import CvBridge
import torch
import cv2
import numpy as np
import math, pandas

class YOLOv5VisionNode(Node):
    def __init__(self):
        super().__init__('yolov5_vision_node')
        self.bridge = CvBridge()
        self.color_sub = self.create_subscription(Image, '/camera/color/image_raw', self.color_callback, 10)
        self.depth_sub = self.create_subscription(Image, '/camera/aligned_depth_to_color/image_raw', self.depth_callback, 10)
        self.info_sub = self.create_subscription(CameraInfo, '/camera/color/camera_info', self.info_callback, 10)
        self.pose_pub = self.create_publisher(PoseStamped, '/workpiece_pose', 10)
        self.color_image = None
        self.depth_image = None
        self.camera_info = None
        self.model = torch.hub.load('ultralytics/yolov5', 'custom', path='/home/atharva/trial_ws/src/yolov5.pt', source='local')

    def info_callback(self, msg):
        self.camera_info = msg

    def color_callback(self, msg):
        self.color_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        self.process()

    def depth_callback(self, msg):
        self.depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')

    def process(self):
        if self.color_image is None or self.depth_image is None or self.camera_info is None:
            return
        # YOLOv5 inference
        results = self.model(self.color_image)
        # Results: pandas dataframe with xmin, ymin, xmax, ymax, confidence, class, name
        df = results.pandas().xyxy[0]
        if df.empty:
            return
        # Pick first detected object (or filter by class name)
        row = df.iloc[0]
        xmin, ymin, xmax, ymax = map(int, [row.xmin, row.ymin, row.xmax, row.ymax])
        cx = int((xmin + xmax) / 2)
        cy = int((ymin + ymax) / 2)
        # Draw box
        img = self.color_image.copy()
        cv2.rectangle(img, (xmin, ymin), (xmax, ymax), (0,255,0), 2)
        cv2.circle(img, (cx, cy), 5, (0,0,255), -1)

        # Depth
        if self.depth_image.shape[:2] != img.shape[:2]:
            depth_img_resized = cv2.resize(self.depth_image, (img.shape[1], img.shape[0]))
        else:
            depth_img_resized = self.depth_image
        depth_value = float(depth_img_resized[cy, cx]) / 1000.0

        # Camera intrinsics
        K = self.camera_info.k
        fx, fy = K[0], K[4]
        cx_i, cy_i = K[2], K[5]
        X = (cx - cx_i) * depth_value / fx
        Y = (cy - cy_i) * depth_value / fy
        Z = depth_value

        # Compose PoseStamped
        pose_msg = PoseStamped()
        pose_msg.header.stamp = self.get_clock().now().to_msg()
        pose_msg.header.frame_id = self.camera_info.header.frame_id
        pose_msg.pose.position.x = X
        pose_msg.pose.position.y = Y
        pose_msg.pose.position.z = Z
        # Orientation estimation left as an exercise (could use object's angle or default downwards)
        pose_msg.pose.orientation.w = 1.0  # Identity quaternion

        self.pose_pub.publish(pose_msg)

        cv2.imshow("YOLOv5 Detection", img)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = YOLOv5VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
