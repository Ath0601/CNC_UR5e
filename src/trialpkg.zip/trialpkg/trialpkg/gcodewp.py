import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, PoseArray
from visualization_msgs.msg import Marker, MarkerArray
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.action import ExecuteTrajectory
from rclpy.action import ActionClient
from trialpkg.gcodeparser import GCodeParser

class CartesianTrajectoryNode(Node):
    def __init__(self):
        super().__init__('cartesian_trajectory_node')
        # Visualization
        self.marker_pub = self.create_publisher(MarkerArray, '/gcode_waypoint_markers', 1)
        self.posearray_pub = self.create_publisher(PoseArray, '/gcode_waypoint_poses', 1)
        self.filepath = '/home/atharva/trial_ws/src/trialpkg/gcodefiles/big_movements_50cm_xy.gcode'
        # MoveIt clients
        self.cartesian_client = self.create_client(GetCartesianPath, '/compute_cartesian_path')
        self.execute_client = ActionClient(self, ExecuteTrajectory, '/execute_trajectory')
        self.get_logger().info('Waiting for MoveIt services...')
        self.cartesian_client.wait_for_service()
        self.execute_client.wait_for_server()
        self.get_logger().info('Connected to MoveIt.')

        # Parse GCode and send waypoints
        parser = GCodeParser(self.filepath, debug=True)
        self.waypoints = parser.parse()
        self.get_logger().info(f"DEBUG: {len(self.waypoints)} waypoints parsed from {self.filepath}")
        self.visualize_waypoints(self.waypoints)
        self.plan_and_execute(self.waypoints)

    def visualize_waypoints(self, poses):
        # Publish markers for RViz
        marker_array = MarkerArray()
        for i, pose in enumerate(poses):
            m = Marker()
            m.header.frame_id = 'base_link'
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = 'gcode_waypoints'
            m.id = i
            m.type = Marker.SPHERE
            m.action = Marker.ADD
            m.pose = pose
            m.scale.x = m.scale.y = m.scale.z = 0.01
            m.color.r = 1.0
            m.color.g = 0.5
            m.color.b = 0.2
            m.color.a = 1.0
            marker_array.markers.append(m)
        self.marker_pub.publish(marker_array)
        pa = PoseArray()
        pa.header.frame_id = 'base_link'
        pa.poses = poses
        self.posearray_pub.publish(pa)
        self.get_logger().info(f"Published {len(poses)} waypoint markers and PoseArray.")
        if len(poses) > 0:
            for i, pose in enumerate(poses[:5]):
                self.get_logger().info(f"DEBUG Waypoint {i}: x={pose.position.x}, y={pose.position.y}, z={pose.position.z}")
        else:
            self.get_logger().warn("No waypoints parsed!")

    def plan_and_execute(self, poses):
        req = GetCartesianPath.Request()
        req.header.frame_id = 'base_link'
        req.group_name = 'manipulator'
        req.link_name = 'end_mill_link'
        req.max_step = 0.01
        req.jump_threshold = 0.0
        req.avoid_collisions = True
        req.waypoints = poses

        self.get_logger().info(f"Requesting Cartesian path through {len(poses)} waypoints...")
        future = self.cartesian_client.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        result = future.result()

        if result is not None and result.fraction > 0.95:
            self.get_logger().info(f"Planned Cartesian path ({result.fraction*100:.3f}%). Sending to execution...")
            goal_msg = ExecuteTrajectory.Goal()
            goal_msg.trajectory = result.solution
            exec_future = self.execute_client.send_goal_async(goal_msg)
            rclpy.spin_until_future_complete(self, exec_future)
            exec_result = exec_future.result()
            self.get_logger().info(f"Execution result: {exec_result}")
        else:
            self.get_logger().error(f"Planning failed or low fraction ({result.fraction if result else 0:.3f}). Check your waypoints or robot workspace.")
            

def main(args=None):
    rclpy.init(args=args)
    node = CartesianTrajectoryNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
