import rclpy, threading
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Pose
from trialpkg.msg import WorkpieceInfo
from moveit_msgs.srv import GetCartesianPath
from moveit_msgs.action import ExecuteTrajectory
from rclpy.action import ActionClient
import numpy as np
from tf2_ros import Buffer, TransformListener
from tf2_geometry_msgs import do_transform_pose

class CartesianPathClient(Node):
    def __init__(self):
        super().__init__('cartesian_path_client')
        self.workpiece_info = None
        self.info_received = threading.Event()
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.info_sub = self.create_subscription(WorkpieceInfo, '/workpiece_info', self.info_callback, 1)
        self.cartesian_client = self.create_client(GetCartesianPath, '/compute_cartesian_path')
        self.cartesian_client.wait_for_service()
        self.execute_client = ActionClient(self, ExecuteTrajectory, '/execute_trajectory')
        self.execute_client.wait_for_server()

        self.get_logger().info("Ready, waiting for workpiece info.")

    def info_callback(self, msg):
        self.workpiece_info = msg
        self.info_received.set()
        self.get_logger().info(f"Received workpiece info: {msg}")

    def wait_for_tf(self, from_frame, to_frame, timeout=5.0):
        import time
        start = time.time()
        while time.time() - start < timeout:
            try:
                trans = self.tf_buffer.lookup_transform(
                    to_frame, from_frame, rclpy.time.Time())
                return trans
            except Exception:
                rclpy.spin_once(self, timeout_sec=0.1)
        raise RuntimeError(f"TF {from_frame} -> {to_frame} not available.")

    def move_to_workpiece(self):
        info = self.workpiece_info
        # Compose pose in camera frame
        approach = PoseStamped()
        approach.header.frame_id = info.header.frame_id  # usually 'camera_color_optical_frame'
        approach.header.stamp = self.get_clock().now().to_msg()
        approach.pose.position.x = info.x
        approach.pose.position.y = info.y
        approach.pose.position.z = info.z + 0.10  # approach 10cm above
        approach.pose.orientation.w = 1.0  # Facing down; adapt as per your robot/tool

        # Transform pose to base_link
        base_frame = 'base_link'  # or your robot base frame name
        self.get_logger().info(f"Waiting for TF from {info.header.frame_id} to {base_frame}")
        tf = self.wait_for_tf(info.header.frame_id, base_frame)
        approach_in_base = do_transform_pose(approach, tf)

        # Plan trajectory
        request = GetCartesianPath.Request()
        request.group_name = 'manipulator'
        request.header.frame_id = base_frame
        request.start_state.is_diff = True
        request.waypoints = [approach_in_base.pose]
        request.max_step = 0.01
        request.jump_threshold = 0.0
        request.avoid_collisions = True
        future = self.cartesian_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        response = future.result()
        if response and response.fraction > 0.99:
            self.get_logger().info('Approach trajectory planned, executing...')
            goal_msg = ExecuteTrajectory.Goal()
            goal_msg.trajectory = response.solution
            send_goal_future = self.execute_client.send_goal_async(goal_msg)
            rclpy.spin_until_future_complete(self, send_goal_future)
            self.get_logger().info('Approach executed.')
        else:
            self.get_logger().error("Failed to plan approach trajectory!")
        return approach_in_base.pose

    def execute_gcode_trajectory(self, start_pose):
        from trialpkg.gcodeparser import GCodeParser
        parser = GCodeParser("/home/atharva/trial_ws/src/trialpkg/gcodefiles/minimalspiral.gcode")
        gcode_poses = parser.parse()
        offset = np.array([start_pose.position.x, start_pose.position.y, start_pose.position.z])
        poses = []
        for rel_pose in gcode_poses:
            p = Pose()
            p.position.x = rel_pose.position.x + offset[0]
            p.position.y = rel_pose.position.y + offset[1]
            p.position.z = rel_pose.position.z + offset[2]
            p.orientation = start_pose.orientation  # Use same orientation
            poses.append(p)
        request = GetCartesianPath.Request()
        request.group_name = 'manipulator'
        request.header.frame_id = 'base_link'
        request.start_state.is_diff = True
        request.waypoints = poses
        request.max_step = 0.01
        request.jump_threshold = 0.0
        request.avoid_collisions = True
        future = self.cartesian_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        response = future.result()
        if response and response.fraction > 0.99:
            self.get_logger().info('GCode trajectory planned, executing...')
            goal_msg = ExecuteTrajectory.Goal()
            goal_msg.trajectory = response.solution
            send_goal_future = self.execute_client.send_goal_async(goal_msg)
            rclpy.spin_until_future_complete(self, send_goal_future)
            self.get_logger().info('GCode trajectory executed.')
        else:
            self.get_logger().error("Failed to plan GCode trajectory!")

def main(args=None):
    rclpy.init(args=args)
    node = CartesianPathClient()
    node.get_logger().info("Waiting for workpiece info from vision node...")

    if not node.info_received.wait(timeout=15):
        node.get_logger().error("Did not receive workpiece info in time. Exiting.")
        node.destroy_node()
        rclpy.shutdown()
        return

    approach_pose = node.move_to_workpiece()
    node.execute_gcode_trajectory(approach_pose)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
