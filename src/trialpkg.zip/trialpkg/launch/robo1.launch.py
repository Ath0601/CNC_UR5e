from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction, RegisterEventHandler, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, Command, PathJoinSubstitution, FindExecutable
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
    pkg_share = FindPackageShare('trialpkg')

    use_sim_time = LaunchConfiguration('use_sim_time')
    world_path = PathJoinSubstitution([pkg_share, 'worlds', 'empty.world'])
    xacro_file = PathJoinSubstitution([pkg_share, 'urdf', 'ur5e_corrected.urdf.xacro'])
    controller_yaml = PathJoinSubstitution([pkg_share, "config", "controller.yaml"])

    robot_description_content = Command([
        FindExecutable(name='xacro'),
        ' ',
        xacro_file,
        ' ',
        
    ])

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{
            'use_sim_time': use_sim_time,
            'robot_description': ParameterValue(robot_description_content, value_type=str)
        }],
        output='screen'
    )

    controller_manager_node = Node(
    package='controller_manager',
    executable='ros2_control_node',
    parameters=[
        {'use_sim_time': use_sim_time},
        controller_yaml,
        {'robot_description': ParameterValue(robot_description_content, value_type=str)},
    ],
    output='screen'
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([FindPackageShare('ros_gz_sim'), 'launch', 'gz_sim.launch.py'])
        ]),
        launch_arguments={
            'gz_args': ['-r ', world_path],
            'on_exit_shutdown': 'true'
        }.items()
    )

    create_node = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-name', 'ur5e', '-topic', 'robot_description'],
        output='screen'
    )

    joint_state_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen'
    )

    trajectory_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_trajectory_controller', '--controller-manager', '/controller_manager'],
        output='screen'
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            name='use_sim_time',
            default_value='true',
            description='Use simulation (Gazebo) clock if true'
        ),
        gazebo,
        robot_state_publisher_node,
        controller_manager_node,
        create_node,
        RegisterEventHandler(
            OnProcessExit(
                target_action=create_node,
                on_exit=[
                    TimerAction(
                        period=4.0,
                        actions=[joint_state_spawner]
                    )
                ]
            )
        ),
        RegisterEventHandler(
            OnProcessExit(
                target_action=joint_state_spawner,
                on_exit=[
                    TimerAction(
                        period=4.0,
                        actions=[trajectory_controller_spawner]
                    )
                ]
            )
        )
    ])
    